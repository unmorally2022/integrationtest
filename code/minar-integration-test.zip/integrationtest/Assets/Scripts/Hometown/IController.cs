﻿namespace Project.Hometown
{
    public interface IController
    {
        public void OnContextDispose();
    }
}